from pathlib import Path
import sys
import zipfile
import shutil
ROOT = Path('E:/AI-Knowledge').resolve()
sys.path.insert(0, str(ROOT / 'tools'))
import knowledge as k

def guard(p):
    if p.is_symlink() or not p.resolve().is_relative_to(ROOT):
        raise ValueError('拒绝越界或链接路径：' + str(p))

docs = k.manifests(ROOT)
assert k.validate(ROOT) == []
moves = {}
for doc in docs.values():
    old = (ROOT / doc['_manifest']).parent
    stem = k.slug(Path(doc['source_path']).stem)
    new = old.parent / (stem + '--' + doc['id'][:12])
    guard(old)
    guard(new)
    if new.exists():
        raise ValueError('目标已存在：' + str(new))
    artifact = new / ('原文-' + stem + Path(doc['artifact']).suffix)
    moves[doc['artifact']] = artifact.relative_to(ROOT).as_posix()
    moves[doc['note']] = (new / '归档说明.md').relative_to(ROOT).as_posix()

maintenance = ['变更日志.md', '验收记录.md', '验收截图.png', 'install-state.json']
for name in maintenance:
    moves['99-System/' + name] = '99-System/Maintenance/' + name
moves['99-System/知识库首页.md'] = '首页.md'
inbox = [ROOT / '00-Inbox' / name for name in ['deterministic-narrative-result-generation.json', 'hong-kong-assessment-stack.json', 'transactional-access-code-quota.json']]
backup = ROOT / '99-System/Backups/2026-10-11-before-directory-tidy.zip'
guard(backup)
if backup.exists():
    raise ValueError('备份已存在，停止重复清理')
files = [p for p in ROOT.rglob('*') if p.is_file() and not any(x in p.relative_to(ROOT).parts for x in ['.git', 'Backups', '__pycache__'])]
with zipfile.ZipFile(backup, 'x', zipfile.ZIP_DEFLATED) as z:
    for p in files:
        guard(p)
        z.writestr(p.relative_to(ROOT).as_posix(), p.read_bytes())
with zipfile.ZipFile(backup) as z:
    assert z.testzip() is None
    for doc in docs.values():
        data = z.read(doc['artifact'])
        assert k.digest(data) == doc['sha256'] and len(data) == doc['size']

with k.lock(ROOT):
    for doc in docs.values():
        old_dir = (ROOT / doc['_manifest']).parent
        artifact = ROOT / moves[doc['artifact']]
        new_dir = artifact.parent
        old_artifact_name = Path(doc['artifact']).name
        old_dir.rename(new_dir)
        (new_dir / old_artifact_name).rename(artifact)
        record = {key: value for key, value in doc.items() if key != '_manifest'}
        record['artifact'] = moves[doc['artifact']]
        record['note'] = moves[doc['note']]
        k.write(new_dir / 'manifest.json', k.dump(record))
    for old, new in moves.items():
        if old.startswith('05-Research/'):
            continue
        source, destination = ROOT / old, ROOT / new
        guard(source)
        guard(destination)
        if destination.exists():
            raise ValueError('维护文件目标已存在：' + str(destination))
        destination.parent.mkdir(parents=True, exist_ok=True)
        source.rename(destination)

    original_paths = {moves[d['artifact']] for d in docs.values()}
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.suffix not in ['.md', '.json']:
            continue
        rel = p.relative_to(ROOT).as_posix()
        if any(part in p.relative_to(ROOT).parts for part in ['.git', 'Backups', '__pycache__']) or rel in original_paths or p.name == 'manifest.json':
            continue
        guard(p)
        content = p.read_text(encoding='utf-8-sig')
        for old, new in moves.items():
            content = content.replace(old, new)
        if rel == '首页.md':
            content = content.replace('(知识图谱.html)', '(99-System/知识图谱.html)')
        k.write(p, content)

    for p in inbox:
        guard(p)
        if p.exists():
            p.unlink()
    cache = ROOT / 'tools/__pycache__'
    guard(cache)
    if cache.exists():
        shutil.rmtree(cache)
    for doc in k.manifests(ROOT).values():
        data = (ROOT / doc['artifact']).read_bytes()
        assert k.digest(data) == doc['sha256'] and len(data) == doc['size']
    errors = k.validate(ROOT)
    if errors:
        raise ValueError(errors)
    result = k.build(ROOT)
print(k.dump({'backup': str(backup), 'renamed_archives': len(docs), 'maintenance_files': maintenance, 'cleared_inbox_files': [p.name for p in inbox], 'validate': errors, 'build': result}))
